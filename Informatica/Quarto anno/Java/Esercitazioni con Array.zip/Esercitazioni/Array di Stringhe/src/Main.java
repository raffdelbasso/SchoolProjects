import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		Scanner t = new Scanner(System.in);
		String[] s;
		int dim;
		int i;
		System.out.print("Dimensione array: ");
		dim = t.nextInt();
		s = new String[dim];
		for (i=0; i<dim; i++) {
			System.out.println("Ci troviamo in posizione "+i);
			System.out.print("Inserisci stringa: ");
			s[i] = t.next();
		}
		
		System.out.print("Le stringhe che hai inserito sono:");
		for(i=0; i<dim; i++) {
			System.out.println(s[i]);
		}
		
		int j;
		String appoggio;
		for (i=0; i<dim-1; i++) {
			for (j=i+1; j<dim; j++) {
				if (s[i].compareTo(s[j])>0) {
					appoggio=s[i];
					s[i]=s[j];
					s[j]=appoggio;
				}
			}
		}
		
		for(i=0; i<dim; i++) {
			System.out.println(s[i]);
		}
		
		
		
	}

}
