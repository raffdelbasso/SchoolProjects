import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		Scanner t = new Scanner(System.in);
		int array[];
		int dim;
		int i;
		System.out.print("Dimensione array: ");
		dim = t.nextInt();
		array = new int[dim];
		for (i=0; i<dim; i++) {
			System.out.print("Ci troviamo in posizione "+i+".\nInserire numero: ");
			array[i] = t.nextInt();
		}
		// Abbiamo l'array pronto. Visualizziamolo
		System.out.println("Questo � l'array che hai creato: ");
		for (i=0; i<dim; i++) {
			System.out.print(array[i]+" ");
		}
		// Adesso, cominciamo a lavorare con esso.
		
		// 1. Conteggio dei numeri pari e dei dispari
		int pari=0, dispari=0;
		for (i=0; i<dim; i++) {
			if (array[i]%2==0) {
				pari++; 
			} else {
				dispari++;
			}
		}
		System.out.println("I numeri pari sono "+pari+" e i numeri dispari sono "+dispari+".");
		// 2. Sommo tutti gli elementi di un numero dato
		int aumento;
		System.out.print("Di quanti numeri vuoi aumentare tutti gli elementi? ");
		aumento = t.nextInt();
		for (i=0; i<dim; i++) {
			array[i]+=aumento;
		}
		
		// Rivisualizzo l'array
		System.out.println("Ecco l'array dopo l'aumento:");
		for (i=0; i<dim; i++) {
			System.out.print(array[i]+" ");
		}
		System.out.println();
		
		// 3. Scambio di due elementi
		int pos1, pos2;
		System.out.print("Primo elemento da spostare: ");
		pos1 = t.nextInt();
		System.out.print("Secondo elemento da spostare: ");
		pos2 = t.nextInt();
		int appoggio;
		appoggio=array[pos1];
		array[pos1]=array[pos2];
		array[pos2]=appoggio;
		// Rivisualizzo l'array
		System.out.println("Ecco l'array dopo lo scambio:");
		for (i=0; i<dim; i++) {
			System.out.print(array[i]+" ");
		}
		System.out.println();
		
		// 4. Ordinamento in ordine crescente
		int j;
		for (i=0; i<dim-1; i++) {
			for (j=i+1; j<dim; j++) {
				if (array[i]>array[j]) {
					appoggio=array[i];
					array[i]=array[j];
					array[j]=appoggio;
				}
			}
		}
		// Rivisualizzo l'array
		System.out.println("Ecco l'array dopo l'ordinamento: ");
		for (i=0; i<dim; i++) {
			System.out.print(array[i]+" ");
		}
		System.out.println();
		t.close();
	}

}
