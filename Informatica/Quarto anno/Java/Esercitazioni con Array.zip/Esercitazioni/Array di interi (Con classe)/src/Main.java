import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		Scanner t = new Scanner(System.in);
		Array a;
		int dim;
		System.out.print("Dimensione array: ");
		dim = t.nextInt();
		a = new Array(dim);
		int i;
		int elemento;
		for (i=0; i<a.getDim(); i++) {
			System.out.print("Ci troviamo in posizione "+i);
			System.out.print("Inserisci numero: ");
			elemento = t.nextInt();
			a.setElemento(i, elemento);
		}
		a.aumentaTutti(6);
		System.out.println(a.visualizza());
		System.out.println("Numeri pari: "+a.contaPari()+"\nNumeri dispari: "+a.contaDispari());
		a.scambio(4, 6);
		System.out.println(a.visualizza());
		a.ordina();
		System.out.println(a.visualizza());
		t.close();
	}

}
