
public class Array {
	private int dim;
	private int[] array;
	public Array(int dim) {
		this.dim=dim;
		array = new int[dim];
	}
	public int getDim() {
		return dim;
	}
	public void setDim(int dim) {
		this.dim = dim;
	}
	public int getElemento(int pos) {
		return array[pos];
	}
	
	public void setElemento(int pos, int elemento) {
		array[pos]=elemento;
	}
	
	public int contaPari() {
		int i;
		int pari=0;
		for (i=0; i<dim; i++) {
			if (array[i]%2==0) {
				pari++; 
			}
		}
		return pari;
	}
	
	public int contaDispari() {
		int i;
		int dispari=0;
		for (i=0; i<dim; i++) {
			if (array[i]%2!=0) {
				dispari++; 
			}
		}
		return dispari;
	}
	
	public void aumentaTutti(int aumento) {
		int i;
		for (i=0; i<dim; i++) {
			array[i]+=aumento;
		}
	}
	
	public void scambio(int pos1, int pos2) {
		int appoggio;
		appoggio=array[pos1];
		array[pos1]=array[pos2];
		array[pos2]=appoggio;
	}
	
	public void ordina() {
		int i;
		int j;
		int appoggio;
		for (i=0; i<dim-1; i++) {
			for (j=i+1; j<dim; j++) {
				if (array[i]>array[j]) {
					appoggio=array[i];
					array[i]=array[j];
					array[j]=appoggio;
				}
			}
		}
	}
	
	public String visualizza() {
		String msg="";
		int i;
		for (i=0; i<dim; i++) {
			msg+=array[i]+" ";
		}
		return msg;
	}
}
